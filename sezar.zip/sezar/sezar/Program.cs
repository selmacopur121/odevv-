﻿
using System;
using System.Text;

public class sezarsifre
{
  
    public static StringBuilder encrypt(String text, int s)
    {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < text.Length; i++) // string olarak tanımladığımız text'i for dömgüsü ile değerini 0 olarak tanımlayıp text uzunluğunu alıp, bir arttırıyoruz.
        {
            if (char.IsUpper(text[i]))
            {
                char ch = (char)(((int)text[i] +
                                s - 65) % 29 + 65);
                result.Append(ch);
            }
            else
            {
                char ch = (char)(((int)text[i] +
                                s - 97) % 26 + 97);
                result.Append(ch);
            }
        }
        return result;
    }

    public static void Main(String[] args)
    {
        
        int s = 2;//integer değer tanımıyoruz anahtar sayımızı belirlemek için!!
        Console.WriteLine("METİN GİRİNİZ: ");
        string metin = Console.ReadLine();// metin için input değeri almamız gerekiyor!
        Console.WriteLine("SHIFT : " + s);
        Console.WriteLine("ŞİFRELENMİŞ METİN: " + encrypt(metin, s));
    }
}



