﻿//Vigenere Cipher, alfabetik metni şifrelemenin bir yöntemidir.
//Tablo, farklı sıralarda 26 kez yazılan alfabelerden oluşur, her alfabe önceki alfabeye kıyasla döngüsel olarak sola kaydırılır ve 26 olası Sezar Şifresine karşılık gelir .
//Şifreleme işleminin farklı noktalarında, şifre satırlardan birinden farklı bir alfabe kullanır.
//Her noktada kullanılan alfabe, tekrar eden bir anahtar kelimeye bağlıdır.
using System;

class ODEV2
{

	// Bu fonksiyonun anahtarını oluşturur
	
	//orjinal metnin uzunluğuna eşitler
	static String generateKey(String str, String key)
	{
		int x = str.Length;

		for (int i = 0; ; i++)
		{
			if (x == i)
				i = 0;
			if (key.Length == str.Length)
				break;
			key += (key[i]);
		}
		return key;
	}

	// Bu fonksiyon anahtar yardımıyla oluşturulan şifrelenmiş metni döndürür
	
	static String sifremetin(String str, String key)
	{
		String sifre_metin = "";
		
		for (int i = 0; i < str.Length; i++)
		{
			// 0-25 aralığında dönüştürme
			int x = (str[i] + key[i]) % 26; //Düz metin(P) ve anahtar(K), modülo 26'ya eklenir.

			// ASCII tablosundaki alfabeye çevir
			x += 'A';

			sifre_metin += (char)(x);
		}
		return sifre_metin;
	}

	// Bu fonksiyon şifrelenmiş metnin şifresini çözer ve orijinal metni döndürür
	static String originalText(String sifre_metin, String key)
	{
		String orig_text = "";

		for (int i = 0; i < sifre_metin.Length &&
								i < key.Length; i++)
		{
			//  0-25 aralığında
			int x = (sifre_metin[i] -
						key[i] + 26) % 26; // şifreyi çözmek için ise D i = (E i - K i + 26) mod 26 kullanılır.

			//ASIIC tablosundaki alfabeye çevir
			x += 'A';
			orig_text += (char)(x);
		}
		return orig_text;
	}

	public static void Main(String[] args)
	{
		String str = "SELMANURCOPUR";
		String keyword = "ASYUUZ";

		String key = generateKey(str, keyword);
		String sifre_metin= sifremetin(str, key);

		Console.WriteLine("ŞİFRELİ METİN : "
			+ sifre_metin + "\n");

		Console.WriteLine("ORJİNAL METİN : "
			+ originalText(sifre_metin, key));
	}
}

/* This code contributed by PrinciRaj1992 */

